plsmulti = function(data.A,n.A,data.B,n.B){
  if (grepl("Sample",data.A[,1])) {data.A = data.A[,-1]}
  if (grepl("Sample",data.B[,1])) {data.B = data.B[,-1]}
  links.A = colnames(data.A)
  links.B = colnames(data.B)

  if (length(links.A)!=length(links.B)){
    print("Error : Different numbers of links between models")
  } else if(any(links.A == links.B)==F) {
    print("Error : Different links between models")
    } else {

  nb.links = length(links.A)
  links = links.A

  path1 = colMeans(data.A)
  path2 = colMeans(data.B)
  ES1 = apply(data.A,2,sd)
  ES2 = apply(data.B,2,sd)

  DIFF = c()
  T = c()
  SIGN = c()
  A = matrix(NA,ncol=3,nrow=0)

  for (i in 1:nb.links){
  F = round(ES1[i]^2 / ES2[i]^2,3)
  f = round(pf(F,n.A,n.B,lower.tail=FALSE),3)
  ddl = n.A + n.B -2

  diff = round(path1[i]-path2[i],3)

  if (f < .05){
    t = (path1[i] - path2[i]) / sqrt(ES1[i]^2 + ES2[i]^2)
  } else {
    t = (path1[i] - path2[i]) / (sqrt(((((n.A-1)^2)/(ddl))*ES1[i]^2)+((((n.B-1)^2)/(ddl))*ES2[i]^2))*sqrt((1/n.A)+(1/n.B)))
  }

  sign = round(1-pt(t,ddl),3)
  t = round(t,3)

  a = c(diff,t,sign)
  A = rbind(A,a)
  }
  rownames(A) = links
  colnames(A) = c("Diff","t","Sign.")
  print(A)
    }
}
